<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estante Mágica - Login</title>
    <style>
        /* Estilos para o contêiner do formulário */
        .form-container {
            max-width: 400px;
            margin: 130px auto;
            padding: 40px;
            border: 7px solid #ccc;
            border-radius: 10px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
        }

        input {
            width: 100%;
            padding: 10px;
            margin-bottom: 16px;
            box-sizing: border-box;
        }

        button {
            background-color: rgb(159, 106, 187);
            color: #fff;
            padding: 12px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Estante Mágica - Login</h2>

        <!-- Added image -->
        <img src="livro-magico.png" alt="Estante Mági" style="width: 40px; height: auto; margin-bottom: 20px;">

        <?php
        session_start();

        // Verificar se o formulário foi enviado
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $tipo = $_POST["tipo"];
            $login = $_POST["login"];
            $senha = $_POST["senha"];

            // Verificar as credenciais (exemplo simples, você deve usar um método mais seguro)
            if ($tipo === "administrador" && $login === "admin" && $senha === "admin123") {
                // Redirecionar para a página do administrador
                header('Location: compra.php');
                exit();
            } elseif ($tipo === "intermediario" && $login === "intermed" && $senha === "intermed123") {
                // Redirecionar para a página do intermediário
                header('Location: compra.php');
                exit();
            } else {
                // Credenciais inválidas, mostrar mensagem de erro
                echo "<p style='color: red;'>Credenciais inválidas. Tente novamente.</p>";
            }
        }
        ?>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="tipo">Selecione o tipo:</label>
            <select id="tipo" name="tipo">
                <option value="administrador">Administrador</option>
                <option value="intermediario">Intermediário</option>
            </select>

            <label for="login">Login:</label>
            <input type="text" id="login" name="login" required>

            <label for="senha">Senha:</label>
            <input type="password" id="senha" name="senha" required>

            <button type="submit">Login</button>
        </form>

        <p>Não possui cadastro? <a href="cadastro.php">Cadastrar-se</a></p>
        <p><a href="comprasemlogin.php">Não quero me cadastrar</a></p>
    </div>
</body>
</html>
